import { FileUploadResponse } from "./file-upload-response";

describe('FileUploadResponse', () => {
    it('should create an instance', () => {
      expect(new FileUploadResponse()).toBeTruthy();
    });
  });