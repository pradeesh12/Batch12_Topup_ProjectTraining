export class FileUploadResponse{
    fileName!:string;
    contentType!:string;
    url!:string;
}