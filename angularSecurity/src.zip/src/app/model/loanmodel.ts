export class Loanmodel {
        loanId: number;
		loantype: string;
		applicantName: string;
	    applicantAddress: string;
		applicantMobile: string;
		applicantEmail: string;
		applicantAadharr: string;
		applicantPan: string;
		applicantSalary: string;
		loanAmountRequired: string;
		repaymentMonths: string;
        apprej: string;
}
